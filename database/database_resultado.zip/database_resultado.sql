-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.27 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para codatest
CREATE DATABASE IF NOT EXISTS `codatest` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `codatest`;

-- Volcando estructura para tabla codatest.client
CREATE TABLE IF NOT EXISTS `client` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.client: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` (`id`, `firstname`, `lastname`, `email`, `phone`, `photo`, `created_at`, `updated_at`, `deleted`) VALUES
	(1, 'asdad', 'asdasd', 'asda@ffff.com', '5555', 'https://via.placeholder.com/150', '2022-02-15 22:02:33', '2022-02-16 01:45:31', 0),
	(2, 'asasdasdasdd', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-16 02:03:26', '2022-02-16 02:03:49', 0),
	(3, 'asdasd', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-15 22:02:31', NULL, 0),
	(4, 'fffff', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-14 22:06:29', NULL, 0),
	(5, 'sss', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-14 22:06:41', NULL, 0),
	(6, 'asdasda', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-13 22:06:52', NULL, 0),
	(7, 'ssss', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-12 22:07:49', NULL, 0),
	(8, 'jjjj', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-11 22:17:26', NULL, 0),
	(9, 'jkkjkjkjkj', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-10 22:17:37', NULL, 0),
	(10, 'adssadasd', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-09 22:35:35', NULL, 0),
	(11, 'ddasdads', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-08 22:35:49', NULL, 0),
	(12, 'fdsfsfsddsf', 'asd', 'gggg@ggg.com', '5555', 'https://via.placeholder.com/150', '2022-02-07 22:36:12', NULL, 0);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.client_project
CREATE TABLE IF NOT EXISTS `client_project` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.client_project: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `client_project` DISABLE KEYS */;
INSERT INTO `client_project` (`id`, `client_id`, `project_id`, `created_at`, `updated_at`, `deleted`) VALUES
	(3, '1', '1', '2022-02-16 03:01:43', '2022-02-16 03:01:43', 0);
/*!40000 ALTER TABLE `client_project` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.mia_active
CREATE TABLE IF NOT EXISTS `mia_active` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `token` text,
  `status` int NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.mia_active: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mia_active` DISABLE KEYS */;
/*!40000 ALTER TABLE `mia_active` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.mia_item_role
CREATE TABLE IF NOT EXISTS `mia_item_role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `item_id` bigint DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `type` int NOT NULL DEFAULT '0',
  `permission_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.mia_item_role: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mia_item_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `mia_item_role` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.mia_log
CREATE TABLE IF NOT EXISTS `mia_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `type_id` int NOT NULL DEFAULT '0',
  `item_id` bigint NOT NULL DEFAULT '0',
  `data` text,
  `caption` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.mia_log: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mia_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mia_log` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.mia_permission
CREATE TABLE IF NOT EXISTS `mia_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(70) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.mia_permission: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mia_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `mia_permission` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.mia_recovery
CREATE TABLE IF NOT EXISTS `mia_recovery` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `token` text,
  `status` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.mia_recovery: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mia_recovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `mia_recovery` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.mia_role
CREATE TABLE IF NOT EXISTS `mia_role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `parent_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.mia_role: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `mia_role` DISABLE KEYS */;
INSERT INTO `mia_role` (`id`, `title`, `parent_id`) VALUES
	(1, 'Admin', NULL),
	(2, 'Editor', NULL);
/*!40000 ALTER TABLE `mia_role` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.mia_role_access
CREATE TABLE IF NOT EXISTS `mia_role_access` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.mia_role_access: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mia_role_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `mia_role_access` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.mia_user
CREATE TABLE IF NOT EXISTS `mia_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(250) NOT NULL,
  `photo` text,
  `phone` varchar(50) DEFAULT NULL,
  `facebook_id` varchar(100) DEFAULT NULL,
  `role` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  `password` varchar(200) DEFAULT NULL,
  `status` int DEFAULT '0',
  `is_notification` int NOT NULL DEFAULT '0',
  `caption` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.mia_user: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mia_user` DISABLE KEYS */;
INSERT INTO `mia_user` (`id`, `firstname`, `lastname`, `email`, `photo`, `phone`, `facebook_id`, `role`, `created_at`, `updated_at`, `deleted`, `password`, `status`, `is_notification`, `caption`) VALUES
	(1, 'empty', '', 'matias@agencycoda.com', '', '', NULL, 2, '2021-07-27 12:32:21', '2021-07-27 12:32:21', 0, '$2y$10$giSRwmR8uCrRLRupj8GYT.riEOH1GdF7xfGpn7kM9OjAc1DZ0Trgy', 0, 0, NULL);
/*!40000 ALTER TABLE `mia_user` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.migrations: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2021_07_27_122814_project', 1),
	(2, '2022_02_15_164414_client', 1),
	(3, '2022_02_15_165020_client_project', 2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.project
CREATE TABLE IF NOT EXISTS `project` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `caption` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.project: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` (`id`, `user_id`, `title`, `caption`, `created_at`, `updated_at`, `deleted`) VALUES
	(1, 1, 'asd', 'asdasd', NULL, NULL, 0);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;

-- Volcando estructura para tabla codatest.project.old
CREATE TABLE IF NOT EXISTS `project.old` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `caption` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `project_user_idx` (`user_id`),
  CONSTRAINT `project_user` FOREIGN KEY (`user_id`) REFERENCES `mia_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Volcando datos para la tabla codatest.project.old: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `project.old` DISABLE KEYS */;
INSERT INTO `project.old` (`id`, `user_id`, `title`, `caption`, `created_at`, `updated_at`, `deleted`) VALUES
	(1, 1, 'test', 'test', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
/*!40000 ALTER TABLE `project.old` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
